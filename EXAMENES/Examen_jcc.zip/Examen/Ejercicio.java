//Juan Caballero Castillo

public class Ejercicio {
    public static void main(String[] args) {
        int tipoProduc;
        int subTipo;
        int cantidad;   
        int oferta;   
        int promocion = 0;
        int producto = (int) (Math.random() * (4 - 1 + 1) + 1);  // [max,min] -> (Math.random * (max - min + 1) + min)
        
        
        double total;   
        double descuento;
        double precio;
        
        float precioIVA = 0;
        float IVA = 0;

        String nombre;
        String regalo = null;
        
        char promo;


        try {
        System.out.println("Introduzca el tipo de producto:");
        System.out.println("1.Alimentación.");
        System.out.println("2.Electrónica.");
        System.out.println("3.Farmacia.");
        System.out.println("4.Moda.");
        System.out.print("Opción: ");
        tipoProduc = Integer.parseInt(System.console().readLine());


        switch (tipoProduc) {
            case 1:
                System.out.println("Introduzca el tipo de producto:");
                System.out.println("1.Huevos.");
                System.out.println("2.Leche.");
                System.out.println("3.Pan.");
                System.out.println("4.Fruta.");
                System.out.println("5.Verdura.");
                System.out.println("6.Otros.");
                System.out.print("Opción: ");
                subTipo = Integer.parseInt(System.console().readLine());
                         
                System.out.print("Introduzca el nombre del producto: ");
                nombre = System.console().readLine();

                System.out.print("Introduzca la cantidad de productos: ");
                cantidad = Integer.parseInt(System.console().readLine());

                System.out.print("Introduzca el precio por unidad del producto: ");
                precio = Double.parseDouble(System.console().readLine()); 
            
                System.out.println("\033[1m Factura \033[0m");
                System.out.println("-----------------------------------------");
                System.out.printf("Artículo \t %s\n",nombre);
                System.out.printf("Precio \t $ %.2f/unidad\n",precio);
                System.out.printf("Cantidad \t %d\n",cantidad);
                System.out.println("-----------------------------------------");
                
                total = (double) (precio * cantidad);                               //Calculamos el total

                System.out.printf("Total \t $ %.2f/unidad\n",total);

                switch (subTipo) {                                                  //Seleccionamos el IVA dependiendo del subTipo
                    case 1,2,3,4,5:
                        IVA = 4;
                        precioIVA = (float) ((total * (float) (IVA/100)));
                        break;
                    case 6:
                        IVA = 10;
                        precioIVA = (float) ((total * (float) (IVA/100)));
                        break;
                }

            

                System.out.printf("IVA al %.0f%% \t $ %.2f \n",IVA,precioIVA);
                System.out.println("-----------------------------------------");
                System.out.printf("Total con IVA \t $ %.2f\n",precioIVA + total);

                break;

            case 2:
                System.out.print("Introduzca el nombre del producto: ");
                nombre = System.console().readLine();
                IVA = 20;                                                           //El IVA obliagatoriamente 20%

                System.out.print("Introduzca la cantidad de productos: ");
                cantidad = Integer.parseInt(System.console().readLine());

                System.out.print("Introduzca el precio por unidad del producto: ");
                precio = Double.parseDouble(System.console().readLine());  

                System.out.print("¿Tiene promoción? (s/n): ");
                promo = System.console().readLine().toLowerCase().charAt(0); //Seleccionamos el caracter de la posición 0

                switch (promo) {
                    case 's':
                        promo = 1;
                        break;
                    case 'n':
                        promo = 2;
                        break;
                
                    default:
                        System.out.println("**Error El dato introducido es erroneo");
                        break;
                }

                System.out.println("\033[1m Factura \033[0m");
                System.out.println("-----------------------------------------");
                System.out.printf("Artículo \t %s\n",nombre);
                System.out.printf("Precio \t $ %.2f/unidad\n",precio);
                System.out.printf("Cantidad \t %d\n",cantidad);
                System.out.println("-----------------------------------------");
                
                total = (double) (precio * cantidad);                             //Calculamos el total

                System.out.printf("Subtotal \t $ %.2f/unidad\n",total);

                if (promo == 1) {
                    promocion = (int) (Math.random() * (25 - 10 + 1 ) + 10);      //Generamos un numero aleatorio entre el 10% y 25% para el descuento
                }else if (promo == 2) {
                    promocion = 0;
                }

                descuento = (float) ((total * ((float)promocion/100)));         // Aplicamos el descuento

                System.out.printf("Descuento %d%% \t $ %.2f/unidad\n",promocion,-descuento);
                System.out.printf("Total tras desc.\t $ %.2f/unidad\n",total - descuento);

                precioIVA = (float) (((total - descuento) * (float) (IVA/100)));        //Calculamos el IVA

                System.out.printf("IVA al %.0f%% \t $ %.2f\n",IVA,precioIVA);
                System.out.println("-----------------------------------------");
                System.out.printf("Total con IVA \t $ %.2f\n",precioIVA + total - descuento);

                break;
            case 3:
                System.out.print("Introduzca el nombre del producto: ");
                nombre = System.console().readLine();
                IVA = 4;

                System.out.print("Introduzca la cantidad de productos: ");
                cantidad = Integer.parseInt(System.console().readLine());

                System.out.print("Introduzca el precio por unidad del producto: ");
                precio = Double.parseDouble(System.console().readLine()); 

                System.out.println("\033[1m Factura \033[0m");
                System.out.println("-----------------------------------------");
                System.out.printf("Artículo \t %s\n",nombre);
                System.out.printf("Precio \t $ %.2f/unidad\n",precio);
                System.out.printf("Cantidad \t %d\n",cantidad);
                System.out.println("-----------------------------------------");
            
                total = (double) (precio * cantidad);                       //Calculamos el total

                System.out.printf("Total \t $ %.2f/unidad\n",total);

            

                precioIVA = (float) ((total * (float) (IVA/100)));          //Calculamos el IVA

                System.out.printf("IVA al %.0f%% \t $ %.2f\n",IVA,precioIVA);
                System.out.println("-----------------------------------------");
                System.out.printf("Total con IVA \t $ %.2f\n",precioIVA + total);

                break;
            case 4:
            System.out.print("Introduzca el nombre del producto: ");
            nombre = System.console().readLine();
            IVA = 4;                                                    //El IVA es obligatoriamente el 4%

            System.out.print("Introduzca la cantidad de productos: ");
            cantidad = Integer.parseInt(System.console().readLine());
            
            if (cantidad > 3) {                                         //Hacemos la oferta de 3x2
                oferta = cantidad - (cantidad / 3);
            }else{
                oferta = cantidad;
            }    

            System.out.print("Introduzca el precio por unidad del producto: ");
            precio = Double.parseDouble(System.console().readLine()); 

            System.out.println("\033[1m Factura \033[0m");
            System.out.println("-----------------------------------------");
            System.out.printf("Artículo \t %s\n",nombre);
            System.out.printf("Precio \t $ %.2f/unidad\n",precio);
            System.out.printf("Cantidad \t %d\n",cantidad);
            System.out.println("-----------------------------------------");
            System.out.printf("Promoción 3x2 \t Pagas solo %d unidades\n",oferta);
        
            total = (double) (precio * oferta);                             //Calculamos el total

            System.out.printf("Total \t $ %.2f/unidad\n",total);

            precioIVA = (float) ((total * (float) (IVA/100)));              //Calculamos el precio del IVA


            System.out.printf("IVA al %.0f%% \t $ %.2f \n",IVA,precioIVA);
            System.out.println("-----------------------------------------");
            System.out.printf("Total con IVA \t $ %.2f \n",precioIVA + total);

                break;   
        }
        
        switch (producto) {             //Se genera un numero aleatorio para el regalo
            case 1:
                regalo = "descuento de un 5% en la próxima compra";
                break;
            case 2:
                regalo = "bolsa reutilizable de regalo";
                break;
            case 3:
                regalo = "vale por un café gratis";
                break;
            case 4:
                regalo = "pegatina oficial de El Porte Inglés";
                break;
        
            default:
                break;
        }
        System.out.println("\uD83C\uDF81\033[1mProducto sorpresa :\033[0m");        //Hacemos el mensaje del producto sorpresa
        System.out.println(regalo);

        } catch (Exception e){
        System.out.println("**Error El valor introducido no es valido");        //Generamos el mensaje por si ocurrre alguna excepción
        } finally{
        System.out.println("¡Muchas gracias por su compra! ¡Que tenga un buen día!");       //Generamos el mensaje final
        }
    }
}